<?php
require_once('Route.php');

use Steampixel\Route;

Route::add('/', function () {
    $json = array(
        'status' => 'ok',
        'message' => 'Welcome to the api',
        'content' => 'This is the content'
    );
    header('Content-type: applicantion/json');
    return json_encode($json);
});
Route::add('/gallery', function () {
    $db = new mysqli('localhost', 'root', '', 'forum-wedkarskie');
    $result = $db->query('SELECT * FROM galeria');
    $photos = array();
    while ($row = $result->fetch_assoc()) {
        $photos[] = $row;
    }
    $json = array(
        'status' => 'ok',
        'message' => 'Here are the photos',
        'content' => $photos

    );
    header('Content-type: applicantion/json');
    return json_encode($json);
});
Route::add('/login', function () {
$data = file_get_contents('php://login');
return var_dump($_POST);
}, 'post');
Route::add('/account/([0-9)', function($accountNo)  {

});
Route::add('/account', function () {

    session_start();
    
    if (!isset($_SESSION['user_id'])) {

        $json = array(
            'status' => 'error',
            'message' => 'Uzytkownik sie nie zalogowal',
        );
        header('Content-type: application/json');
        return json_encode($json);
    }

    $userId = $_SESSION['user_id'];
    $db = new mysqli('localhost', 'root', '', 'forum-wedkarskie');
    
   
    $stmt = $db->prepare('SELECT * FROM user WHERE id = ?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $json = array(
            'status' => 'ok',
            'message' => 'Pobrano informacje o koncie użytkownika',
            'content' => $user
        );
    } else {
        $json = array(
            'status' => 'error',
            'message' => 'Użytkownik nie został znaleziony',
        );
    }

    header('Content-type: application/json');
    return json_encode($json);
});
Route::add('/register', function () {
    $data = json_decode(file_get_contents('php://input'), true); 
    $username = $data['username'] ?? null; 
    $password = $data['password'] ?? null; 

    if (empty($username) || empty($password)) {
        $json = array(
            'status' => 'error',
            'message' => 'Wymagana jest nazwa użytkownika i hasło',
        );
        header('Content-type: application/json');
        return json_encode($json);
    };

  
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $db = new mysqli('localhost', 'root', '', 'forum-wedkarskie');


    $stmt = $db->prepare('SELECT * FROM user WHERE nick = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $json = array(
            'status' => 'error',
            'message' => 'Użytkownik już istnieje',
        );
    } else {
   
        $stmt = $db->prepare('INSERT INTO user (nick, haslo) VALUES (?, ?)');
        $stmt->bind_param('ss', $nick, $hashedhaslo);

        if ($stmt->execute()) {
            $json = array(
                'status' => 'ok',
                'message' => 'Użytkownik został zarejestrowany',
            );
        } else {
            $json = array(
                'status' => 'error',
                'message' => 'Błąd rejestracji',
            );
        }
    }

    header('Content-type: application/json');
    return json_encode($json);
}, 'post');
Route::add('/opinios', function () {
    $db = new mysqli('localhost', 'root', '', 'forum-wedkarskie'); // Connect to the database

    // Check if the request is a POST request to add a new opinion
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        $opinion = $data['opinion'] ?? null; 
        
        if (empty($opinion)) {
            $json = array(
                'status' => 'error',
                'message' => 'Wymagana jest opinia',
            );
            header('Content-type: application/json');
            return json_encode($json);
        }

        // Insert the new opinion into the database
        $stmt = $db->prepare('INSERT INTO opinie (opinia) VALUES (?)');
        $stmt->bind_param('s', $opinion);

        if ($stmt->execute()) {
            $json = array(
                'status' => 'ok',
                'message' => 'Opinia została dodana',
            );
        } else {
            $json = array(
                'status' => 'error',
                'message' => 'Błąd dodawania opinii',
            );
        }
    } else {
        // Assuming a GET request to retrieve opinions
        $result = $db->query('SELECT * FROM opinie');
        $opinions = array();
        while ($row = $result->fetch_assoc()) {
            $opinions[] = $row;
        }

        $json = array(
            'status' => 'ok',
            'message' => 'Here are the opinions',
            'content' => $opinions
        );
    }

    header('Content-type: application/json');
    return json_encode($json);
}, 'get'); // Allow GET requests to retrieve opinions

Route::run('/api');
