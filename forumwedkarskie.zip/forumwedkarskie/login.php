<?php
// Sprawdź, czy formularz został wysłany
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Połączenie z bazą danych
    $host = 'localhost'; // Zmień na odpowiedni host
    $db = 'forum-wedkarskie';
    $user = 'root'; // Zmień na odpowiedniego użytkownika bazy danych
    $pass = ''; // Zmień na hasło użytkownika bazy danych

    $conn = new mysqli($host, $user, $pass, $db);

    // Sprawdzenie połączenia
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Sanityzacja i pobranie danych z formularza
    $email = $_POST['email'];
    $haslo = $_POST['haslo'];

    // Wyszukiwanie użytkownika w bazie
    $sql = "SELECT haslo FROM user WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();
        
        // Weryfikacja hasła
        if (password_verify($haslo, $hashed_password)) {
            echo "Logowanie zakończone sukcesem!";
            // Możesz tutaj dodać kod do sesji, aby zapamiętać zalogowanego użytkownika
        } else {
            echo "Nieprawidłowe hasło.";
        }
    } else {
        echo "Użytkownik o podanym e-mailu nie istnieje.";
    }

    // Zamknięcie połączenia
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Logowanie</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Formularz Logowania </h1> 
    <img src="logo.jpg" alt="logo" class="logo">
    
    <form method="post" action="">
        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required><br>

        <label for="haslo">Hasło:</label>
        <input type="password" id="haslo" name="haslo" required><br>

        <input type="submit" value="Zaloguj się">
    </form>
</body>
</html>